package pairofDices;

public class PairOfDicesApp {
    public static void main(String[] args) {
        PairOfDices pairOfDice = new PairOfDices();
        pairOfDice.playPairOfDice();
    }
}
