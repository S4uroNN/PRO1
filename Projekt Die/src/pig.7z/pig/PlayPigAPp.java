package pig;

public class PlayPigAPp {
    public static void main(String[] args) {
        PlayPig ply = new PlayPig();
        ply.startGame();
    }


}
